
-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `blogs`
--

DROP TABLE IF EXISTS `blogs`;
CREATE TABLE IF NOT EXISTS `blogs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `author_id` int NOT NULL,
  `photo_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `blogs`
--

INSERT INTO `blogs` (`id`, `author_id`, `photo_id`, `title`, `description`, `created_at`, `deleted_at`) VALUES
(1, 1, 7, 'Blog1', 'test 1', '2025-01-29 08:38:40', '0000-00-00 00:00:00'),
(2, 1, 6, 'tt', 'tt', '2025-01-29 08:40:31', '0000-00-00 00:00:00'),
(3, 1, 3, 'dd', 'dd', '2025-01-29 08:44:25', '2025-01-30 13:52:46'),
(4, 1, 4, 'tt', 'tt', '2025-01-29 08:46:10', '0000-00-00 00:00:00'),
(5, 1, 5, 'test', 'test', '2025-01-30 13:37:55', '0000-00-00 00:00:00'),
(6, 1, 0, 'test', 'test', '2025-01-30 13:44:44', '0000-00-00 00:00:00'),
(7, 1, 12, 'dd', 'dd', '2025-02-01 10:11:22', '0000-00-00 00:00:00'),
(8, 1, 11, 'd', 'd', '2025-02-01 10:12:41', '0000-00-00 00:00:00'),
(9, 1, 10, 'dd', 'dd', '2025-02-01 11:02:04', '0000-00-00 00:00:00'),
(10, 1, 13, 'dd', 'dd', '2025-02-01 11:13:09', '0000-00-00 00:00:00'),
(11, 1, 0, 'test', 'NULL', '2025-02-01 12:05:50', '0000-00-00 00:00:00'),
(12, 1, 0, 'testddssd', 'NULL', '2025-02-01 12:09:31', '0000-00-00 00:00:00'),
(13, 1, 19, 'dd', 'dsfds', '2025-02-01 12:11:03', '0000-00-00 00:00:00'),
(14, 1, 0, 'dd', 'NULL', '2025-02-01 12:11:59', '0000-00-00 00:00:00'),
(15, 1, 14, 'dd', 'dd', '2025-02-01 12:17:46', '0000-00-00 00:00:00'),
(16, 1, 15, 'ddsf', 'dsdfs', '2025-02-01 12:32:58', '0000-00-00 00:00:00'),
(17, 1, 16, 'dd', 'dd', '2025-02-01 12:33:52', '0000-00-00 00:00:00'),
(18, 1, 17, 'dd', 'dd', '2025-02-01 12:35:01', '0000-00-00 00:00:00'),
(19, 1, 18, 'dsdsf', 'sdffd', '2025-02-01 12:37:12', '0000-00-00 00:00:00');
